/************************************************************************
* TITLE: lecture.c             
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
#include "lecture.h"


absorp lecture(FILE* file_pf, int* file_state){

	absorp myAbsorp;
	*file_state=EOF;
	
	return myAbsorp; // return EOF flag

}

