/************************************************************************
* TITLE: integration.c             
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
void integrationTest(char* filename)
{

}