/************************************************************************
* TITLE: fir.h             
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
#include "define.h"

absorp firTest(char* filename);