/************************************************************************
* TITLE: mesure.c             
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
#include "mesure.h"

oxy mesureTest(char* filename)
{
	oxy myOxy;
	return myOxy;

}

