/************************************************************************
* TITLE: integration.h             
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
#include "define.h"

void integrationTest(char* filename);
