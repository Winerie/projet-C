/************************************************************************
* TITLE: lecture.h             
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
#include "define.h"


absorp lecture(FILE* file_pf, int* file_state);
