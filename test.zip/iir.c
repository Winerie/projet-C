/************************************************************************
* TITLE: iir.c            
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
#include "iir.h"

absorp iirTest(char* filename)
{
	absorp	myAbsorp;
	
	return myAbsorp;

}

