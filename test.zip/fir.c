/************************************************************************
* TITLE: fir.c            
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
#include "fir.h"

absorp firTest(char* filename)
{
	absorp	myAbsorp;
	
	return myAbsorp;

}