/************************************************************************
* TITLE: mesure.h             
* AUTHOR: Justine LE VEN et Tristan LE COZ            
* DESCRIPTION:       
* VERSION: 1.0 
************************************************************************/
#include "define.h"

oxy mesureTest(char* filename);

	
